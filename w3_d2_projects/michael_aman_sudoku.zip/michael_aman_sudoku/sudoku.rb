require_relative "tile.rb"
require_relative "board.rb"

class Sudoku

    def initialize
        @game_board = Board.new
    end

    def get_position
        p "Enter 2 integers between 0 and 9 (add space between them)"
        pos = gets.chomp.split.map {|val| val.to_i}
        check = pos.map {|i| i < 0 || i > 9}
        if check.include?(true)
            raise ArgumentError.new "Invalid Passed "
        else
            pos
        end
    end

    def get_value
        p "Enter an integer between 0 and 9"
        val = gets.chomp.to_i
        if val < 0 || val > 9
            raise ArgumentError.new "Invalid Passed "
        else
            val
        end
    end

    def run
        while !self.square_win? && !self.row_win? && !self.col_win?
            puts
            @game_board.render
            puts
            position = self.get_position
            puts
            value = self.get_value
            @game_board.[]=(position,value)
            puts
            @game_board.render
            next
        end
    end

    def row_win?
        @game_board.grid.each do |row|
            sorted_row = row.map {|elem| elem.value}.sort 
            if sorted_row != (1..9).to_a
                return false
            end
        end
        true
    end

    def col_win?
        (0...9).each do |i|
            nested = []
            (0...9).each do |j|
                nested << @game_board.grid[j][i].value
            end
            if nested.sort != (1..9).to_a
                return false
            end
        end
        true
    end

    def square_win?
       
        new_gameboard = []
        @game_board.grid.each do |row|
            vals = row.map {|elem| elem.value}
            i = 0
            nested = []
            while i < vals.length
                nested << vals[0...3]
                vals = vals[3..-1]
             
                i += 1
            end
            new_gameboard << nested
        end
        square = []
        (0...3).each do |i|
            nested = []
            new_gameboard.each do |row|
                nested << row[i]
            end
            square << nested[0...3]
            square << nested[3...6]
            square << nested[6...9]
        end
      
        square.each do |s|
            #flatten nested square row 
            flat = s.flatten.sort
            if flat != (0...9).to_a.sort
                return false
            end
        end
        true
    end
            
    

end

s = Sudoku.new  
s.run