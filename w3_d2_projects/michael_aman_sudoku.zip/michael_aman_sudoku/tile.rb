require 'colorize'


class Tile
    attr_reader :value
    def initialize(value=nil)
        if value != nil
            @value = value
        end
    end

    def to_s
        @value.to_s.colorize(:green)
    end
end
